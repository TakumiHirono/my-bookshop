"use strict";sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";const n=e.extend("ns.orders.Component",{metadata:{manifest:"json"}});return n});
//# sourceMappingURL=Component.js.map